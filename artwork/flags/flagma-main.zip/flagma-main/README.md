# Flagma
Flagma - Country Flags With No Hassle!
Flagma helps you to recognize over 260+ country flags at ease. New features and updates are coming soon.
[Get in touch with Me](https://alnahian2003.github.io)

## Preview
![Flagma](https://raw.githubusercontent.com/alnahian2003/flagma/main/ss-flagma.png)


## Flags Images Credit : [Lipis](https://github.com/lipis/flag-icons)
